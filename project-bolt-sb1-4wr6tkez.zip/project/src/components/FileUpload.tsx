import React, { useCallback, useState } from 'react';
import { Upload, FileText, X, File } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [error, setError] = useState<string>('');

  const validateFile = (file: File): boolean => {
    const supportedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!supportedTypes.includes(file.type)) {
      setError('Please select a PDF or DOCX file');
      return false;
    }
    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      setError('File size must be less than 50MB');
      return false;
    }
    setError('');
    return true;
  };

  const handleFileSelect = useCallback((file: File) => {
    if (validateFile(file)) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const supportedFile = files.find(file => 
      file.type === 'application/pdf' || 
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    );
    
    if (supportedFile) {
      handleFileSelect(supportedFile);
    } else {
      setError('Please drop a PDF or DOCX file');
    }
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  }, [handleFileSelect]);

  const clearError = () => setError('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-2xl mb-6 shadow-lg">
            <FileText className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4 font-bangla">Document Reader</h1>
          <p className="text-xl text-gray-300 mb-2 font-bangla">
            Open and read PDF and DOCX documents with Bangla font support
          </p>
          <p className="text-gray-400 font-bangla">
            Drag and drop a document or click to browse • বাংলা ফন্ট সাপোর্ট সহ
          </p>
        </div>

        {/* Upload Area */}
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 cursor-pointer group ${
            isDragOver
              ? 'border-blue-400 bg-blue-400/10 scale-105'
              : 'border-gray-600 hover:border-gray-500 hover:bg-gray-800/50'
          }`}
        >
          <input
            type="file"
            accept=".pdf,.docx"
            onChange={handleFileInput}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className="space-y-6">
            <div className={`transition-all duration-300 ${isDragOver ? 'scale-110' : 'group-hover:scale-105'}`}>
              <Upload className={`w-16 h-16 mx-auto mb-4 transition-colors ${
                isDragOver ? 'text-blue-400' : 'text-gray-400 group-hover:text-gray-300'
              }`} />
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold text-white mb-2 font-bangla">
                {isDragOver ? 'Drop your document here' : 'Choose a document'}
              </h3>
              <p className="text-gray-400 mb-6 font-bangla">
                {isDragOver ? 'Release to upload' : 'or drag and drop it here'}
              </p>
              
              <div className="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors shadow-lg font-bangla">
                <Upload className="w-5 h-5 mr-2" />
                Browse Files
              </div>
            </div>
          </div>

          {/* File Requirements */}
          <div className="mt-8 p-4 bg-gray-800/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-2 font-bangla">Supported Formats:</p>
            <ul className="text-xs text-gray-500 space-y-1 font-bangla">
              <li>• PDF documents (.pdf) • পিডিএফ ডকুমেন্ট</li>
              <li>• Word documents (.docx) • ওয়ার্ড ডকুমেন্ট</li>
              <li>• Maximum file size: 50MB • সর্বোচ্চ ফাইল সাইজ: ৫০ এমবি</li>
              <li>• Full Bangla font support • সম্পূর্ণ বাংলা ফন্ট সাপোর্ট</li>
              <li>• Text-based documents work best for search • সার্চের জন্য টেক্সট-ভিত্তিক ডকুমেন্ট সবচেয়ে ভাল</li>
            </ul>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-6 p-4 bg-red-600/20 border border-red-600/30 rounded-lg flex items-center justify-between">
            <p className="text-red-400 font-bangla">{error}</p>
            <button
              onClick={clearError}
              className="text-red-400 hover:text-red-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Features */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-gray-800/30 rounded-xl border border-gray-700">
            <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <h4 className="font-semibold text-white mb-2 font-bangla">Multi-Format Support</h4>
            <p className="text-sm text-gray-400 font-bangla">Read PDF and DOCX documents with full formatting • সম্পূর্ণ ফরম্যাটিং সহ</p>
          </div>
          
          <div className="text-center p-6 bg-gray-800/30 rounded-xl border border-gray-700">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Upload className="w-5 h-5 text-white" />
            </div>
            <h4 className="font-semibold text-white mb-2 font-bangla">Bangla Font Support</h4>
            <p className="text-sm text-gray-400 font-bangla">Multiple Bangla fonts including Noto Sans Bengali • নোটো সান্স বেঙ্গলি সহ একাধিক বাংলা ফন্ট</p>
          </div>
          
          <div className="text-center p-6 bg-gray-800/30 rounded-xl border border-gray-700">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <File className="w-5 h-5 text-white" />
            </div>
            <h4 className="font-semibold text-white mb-2 font-bangla">Rich Features</h4>
            <p className="text-sm text-gray-400 font-bangla">Search, zoom, print, and navigate with advanced tools • উন্নত টুলস সহ সার্চ, জুম, প্রিন্ট</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileUpload;