import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import mammoth from 'mammoth';
import { 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Minimize2, 
  Download, 
  Printer, 
  Search,
  RotateCw,
  Menu,
  X,
  FileText,
  File,
  Type
} from 'lucide-react';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

interface DocumentReaderProps {
  file: File | null;
  onClose: () => void;
}

const DocumentReader: React.FC<DocumentReaderProps> = ({ file, onClose }) => {
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [scale, setScale] = useState<number>(1.0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [rotation, setRotation] = useState<number>(0);
  const [searchText, setSearchText] = useState<string>('');
  const [showSidebar, setShowSidebar] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [docxContent, setDocxContent] = useState<string>('');
  const [documentType, setDocumentType] = useState<'pdf' | 'docx'>('pdf');
  const [selectedFont, setSelectedFont] = useState<string>('noto-bangla');
  const [showFontSelector, setShowFontSelector] = useState<boolean>(false);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const pageRef = useRef<HTMLDivElement>(null);

  const isPDF = file?.type === 'application/pdf';
  const isDOCX = file?.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

  const fontOptions = [
    { value: 'noto-bangla', label: 'Noto Sans Bengali', class: 'font-noto-bangla' },
    { value: 'kalpurush', label: 'Kalpurush', class: 'font-kalpurush' },
    { value: 'solaiman', label: 'SolaimanLipi', class: 'font-solaiman' },
    { value: 'default', label: 'Default', class: 'font-bangla' }
  ];

  useEffect(() => {
    if (file) {
      if (isPDF) {
        setDocumentType('pdf');
      } else if (isDOCX) {
        setDocumentType('docx');
        loadDocxContent();
      }
    }
  }, [file, isPDF, isDOCX]);

  const loadDocxContent = async () => {
    if (!file || !isDOCX) return;
    
    setIsLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.convertToHtml({ arrayBuffer });
      setDocxContent(result.value);
      setNumPages(1); // DOCX is treated as single page
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading DOCX:', error);
      setIsLoading(false);
    }
  };

  const onDocumentLoadSuccess = useCallback(({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setIsLoading(false);
  }, []);

  const changePage = useCallback((offset: number) => {
    if (documentType === 'docx') return; // DOCX doesn't have pages
    
    setPageNumber(prevPageNumber => {
      const newPageNumber = prevPageNumber + offset;
      return Math.max(1, Math.min(newPageNumber, numPages));
    });
  }, [numPages, documentType]);

  const goToPage = useCallback((page: number) => {
    if (documentType === 'docx') return;
    setPageNumber(Math.max(1, Math.min(page, numPages)));
  }, [numPages, documentType]);

  const changeScale = useCallback((newScale: number) => {
    setScale(Math.max(0.5, Math.min(newScale, 3.0)));
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  const handleRotate = useCallback(() => {
    if (documentType === 'pdf') {
      setRotation(prev => (prev + 90) % 360);
    }
  }, [documentType]);

  const handleDownload = useCallback(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
      URL.revokeObjectURL(url);
    }
  }, [file]);

  const handlePrint = useCallback(() => {
    if (documentType === 'docx') {
      const selectedFontClass = fontOptions.find(f => f.value === selectedFont)?.class || 'font-bangla';
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Print Document</title>
              <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
              <link href="https://fonts.googleapis.com/css2?family=Kalpurush&display=swap" rel="stylesheet">
              <link href="https://fonts.googleapis.com/css2?family=SolaimanLipi&display=swap" rel="stylesheet">
              <style>
                body { 
                  font-family: 'Noto Sans Bengali', 'Kalpurush', 'SolaimanLipi', 'Vrinda', 'Akaash', 'Mukti', 'Siyam Rupali', 'Nikosh', sans-serif; 
                  line-height: 1.8; 
                  margin: 40px;
                  font-feature-settings: "kern" 1, "liga" 1, "calt" 1;
                  text-rendering: optimizeLegibility;
                }
                h1, h2, h3, h4, h5, h6 { margin-top: 20px; margin-bottom: 10px; }
                p { margin-bottom: 10px; }
                .font-noto-bangla { font-family: 'Noto Sans Bengali', sans-serif; }
                .font-kalpurush { font-family: 'Kalpurush', sans-serif; }
                .font-solaiman { font-family: 'SolaimanLipi', sans-serif; }
                .font-bangla { font-family: 'Noto Sans Bengali', 'Kalpurush', 'SolaimanLipi', 'Vrinda', 'Akaash', 'Mukti', 'Siyam Rupali', 'Nikosh', sans-serif; }
                @media print { body { margin: 0; } }
              </style>
            </head>
            <body class="${selectedFontClass}">${docxContent}</body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    } else {
      window.print();
    }
  }, [documentType, docxContent, selectedFont, fontOptions]);

  const handleFontChange = (fontValue: string) => {
    setSelectedFont(fontValue);
    setShowFontSelector(false);
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (documentType === 'pdf') {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
          e.preventDefault();
          changePage(-1);
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
          e.preventDefault();
          changePage(1);
        }
      }
      if (e.key === 'Escape' && isFullscreen) {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [changePage, isFullscreen, toggleFullscreen, documentType]);

  if (!file) return null;

  const selectedFontClass = fontOptions.find(f => f.value === selectedFont)?.class || 'font-bangla';

  return (
    <div 
      ref={containerRef}
      className={`fixed inset-0 bg-gray-900 text-white transition-all duration-300 ${
        isFullscreen ? 'z-50' : 'z-40'
      }`}
    >
      {/* Header Toolbar */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-gray-800/95 backdrop-blur-sm border-b border-gray-700">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2">
              {documentType === 'pdf' ? (
                <FileText className="w-5 h-5 text-blue-400" />
              ) : (
                <File className="w-5 h-5 text-emerald-400" />
              )}
              <span className="font-medium truncate max-w-xs">
                {file.name}
              </span>
              <span className="text-xs bg-gray-700 px-2 py-1 rounded uppercase">
                {documentType}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Font Selector */}
            <div className="relative">
              <button
                onClick={() => setShowFontSelector(!showFontSelector)}
                className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                title="Select Bangla Font"
              >
                <Type className="w-4 h-4" />
              </button>
              {showFontSelector && (
                <div className="absolute top-full right-0 mt-2 bg-gray-800 border border-gray-700 rounded-lg shadow-xl z-20 min-w-48">
                  <div className="p-2">
                    <div className="text-xs text-gray-400 mb-2 px-2">Bangla Fonts</div>
                    {fontOptions.map((font) => (
                      <button
                        key={font.value}
                        onClick={() => handleFontChange(font.value)}
                        className={`w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                          selectedFont === font.value
                            ? 'bg-blue-600 text-white'
                            : 'hover:bg-gray-700 text-gray-300'
                        } ${font.class}`}
                      >
                        {font.label}
                        <div className="text-xs opacity-70 mt-1">
                          আমার সোনার বাংলা
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search in document"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                className={`pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${selectedFontClass}`}
              />
            </div>

            {/* Page Navigation - Only for PDF */}
            {documentType === 'pdf' && (
              <div className="flex items-center space-x-2 bg-gray-700 rounded-lg px-3 py-2">
                <button
                  onClick={() => changePage(-1)}
                  disabled={pageNumber <= 1}
                  className="p-1 rounded hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  title="Previous page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="flex items-center space-x-2 text-sm">
                  <input
                    type="number"
                    min="1"
                    max={numPages}
                    value={pageNumber}
                    onChange={(e) => goToPage(parseInt(e.target.value) || 1)}
                    className="w-12 text-center bg-transparent border-none focus:outline-none"
                  />
                  <span className="text-gray-400">/ {numPages}</span>
                </div>
                <button
                  onClick={() => changePage(1)}
                  disabled={pageNumber >= numPages}
                  className="p-1 rounded hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  title="Next page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Zoom Controls */}
            <div className="flex items-center space-x-1 bg-gray-700 rounded-lg p-1">
              <button
                onClick={() => changeScale(scale - 0.25)}
                disabled={scale <= 0.5}
                className="p-2 rounded hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Zoom out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-3 py-2 text-sm min-w-16 text-center">
                {Math.round(scale * 100)}%
              </span>
              <button
                onClick={() => changeScale(scale + 0.25)}
                disabled={scale >= 3.0}
                className="p-2 rounded hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Zoom in"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            {/* Tools */}
            <div className="flex items-center space-x-1">
              {documentType === 'pdf' && (
                <button
                  onClick={handleRotate}
                  className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                  title="Rotate"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              )}
              {documentType === 'pdf' && (
                <button
                  onClick={() => setShowSidebar(!showSidebar)}
                  className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                  title="Toggle sidebar"
                >
                  <Menu className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={toggleFullscreen}
                className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
              <button
                onClick={handlePrint}
                className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                title="Print"
              >
                <Printer className="w-4 h-4" />
              </button>
              <button
                onClick={handleDownload}
                className="p-2 rounded-lg hover:bg-gray-700 transition-colors"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex h-full pt-16">
        {/* Sidebar - Only for PDF */}
        {showSidebar && documentType === 'pdf' && (
          <div className="w-64 bg-gray-800 border-r border-gray-700 overflow-y-auto">
            <div className="p-4">
              <h3 className="font-semibold text-sm text-gray-300 mb-4">Pages</h3>
              <div className="space-y-2">
                {Array.from({ length: numPages }, (_, i) => i + 1).map((page) => (
                  <button
                    key={page}
                    onClick={() => goToPage(page)}
                    className={`w-full text-left p-2 rounded text-sm transition-colors ${
                      page === pageNumber
                        ? 'bg-blue-600 text-white'
                        : 'hover:bg-gray-700 text-gray-300'
                    }`}
                  >
                    Page {page}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Document Viewer */}
        <div className="flex-1 overflow-auto bg-gray-900">
          <div className="flex justify-center min-h-full p-8">
            {isLoading && (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
              </div>
            )}
            
            {documentType === 'pdf' && !isLoading && (
              <div ref={pageRef} className="shadow-2xl">
                <Document
                  file={file}
                  onLoadSuccess={onDocumentLoadSuccess}
                  loading={
                    <div className="flex items-center justify-center h-96">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
                    </div>
                  }
                  error={
                    <div className="flex items-center justify-center h-96 text-red-400">
                      <div className="text-center">
                        <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>Failed to load PDF file</p>
                      </div>
                    </div>
                  }
                >
                  <Page
                    pageNumber={pageNumber}
                    scale={scale}
                    rotate={rotation}
                    className="transition-all duration-200"
                    renderTextLayer={true}
                    renderAnnotationLayer={true}
                  />
                </Document>
              </div>
            )}

            {documentType === 'docx' && !isLoading && (
              <div 
                className="max-w-4xl w-full bg-white text-gray-900 shadow-2xl rounded-lg overflow-hidden"
                style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}
              >
                <div 
                  className={`p-12 prose prose-lg max-w-none docx-content ${selectedFontClass}`}
                  dangerouslySetInnerHTML={{ __html: docxContent }}
                  style={{ 
                    fontSize: '16px',
                    lineHeight: '1.8',
                    fontFeatureSettings: '"kern" 1, "liga" 1, "calt" 1'
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions Overlay */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex items-center space-x-2 bg-gray-800/95 backdrop-blur-sm rounded-full px-4 py-2 border border-gray-700">
          <button
            onClick={() => changeScale(1.0)}
            className="px-3 py-1 text-xs rounded-full hover:bg-gray-700 transition-colors"
          >
            Fit
          </button>
          <button
            onClick={() => changeScale(1.5)}
            className="px-3 py-1 text-xs rounded-full hover:bg-gray-700 transition-colors"
          >
            150%
          </button>
          <button
            onClick={() => changeScale(2.0)}
            className="px-3 py-1 text-xs rounded-full hover:bg-gray-700 transition-colors"
          >
            200%
          </button>
        </div>
      </div>

      {/* Click outside to close font selector */}
      {showFontSelector && (
        <div 
          className="fixed inset-0 z-10" 
          onClick={() => setShowFontSelector(false)}
        />
      )}
    </div>
  );
};

export default DocumentReader;