import React, { useState } from 'react';
import FileUpload from './components/FileUpload';
import DocumentReader from './components/DocumentReader';

function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleClose = () => {
    setSelectedFile(null);
  };

  return (
    <div className="App">
      {selectedFile ? (
        <DocumentReader file={selectedFile} onClose={handleClose} />
      ) : (
        <FileUpload onFileSelect={handleFileSelect} />
      )}
    </div>
  );
}

export default App;